#include <QWindow>
#include "whatsprogmain.h"
#include "ui_whatsprogmain.h"

using namespace std;

/// Construtor da janela principal da interface
WhatsProgMain::WhatsProgMain(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::WhatsProgMain)
{
  ui->setupUi(this);

  // Item a ser incluido nas tabelas
  QTableWidgetItem *newItem;
  QFont boldFont;
  boldFont.setBold(true);

  // A lista da esquerda (conversas)
  ui->tableConversas->setColumnCount(2);
  ui->tableConversas->setShowGrid(false);
  ui->tableConversas->setSelectionBehavior(QAbstractItemView::SelectRows);
  ui->tableConversas->setSelectionMode(QAbstractItemView::SingleSelection);
  ui->tableConversas->setTabKeyNavigation(false);
  ui->tableConversas->horizontalHeader()->setSectionResizeMode(0,QHeaderView::ResizeToContents);
  ui->tableConversas->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);
  ui->tableConversas->horizontalHeader()->setSectionsClickable(false);
  // O cabecalho
  ui->tableConversas->setStyleSheet("QHeaderView::section { background-color:lightgray }");
  newItem = new QTableWidgetItem("N Msg");
  newItem->setTextAlignment(Qt::AlignCenter);
  newItem->setFont(boldFont);
  ui->tableConversas->setHorizontalHeaderItem(0, newItem);
  newItem = new QTableWidgetItem("Usuario");
  newItem->setTextAlignment(Qt::AlignCenter);
  newItem->setFont(boldFont);
  ui->tableConversas->setHorizontalHeaderItem(1, newItem);

  // A lista da direita (mensagens)
  ui->tableMensagens->setColumnCount(3);
  ui->tableMensagens->setShowGrid(true);
  ui->tableMensagens->setSelectionBehavior(QAbstractItemView::SelectRows);
  ui->tableMensagens->setSelectionMode(QAbstractItemView::NoSelection);
  ui->tableMensagens->setTabKeyNavigation(false);
  ui->tableMensagens->horizontalHeader()->setSectionResizeMode(0,QHeaderView::ResizeToContents);
  ui->tableMensagens->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);
  ui->tableMensagens->horizontalHeader()->setSectionResizeMode(2,QHeaderView::ResizeToContents);
  ui->tableMensagens->horizontalHeader()->setSectionsClickable(false);
  // O cabecalho
  newItem = new QTableWidgetItem("Id");
  newItem->setTextAlignment(Qt::AlignCenter);
  newItem->setFont(boldFont);
  ui->tableMensagens->setHorizontalHeaderItem(0, newItem);
  ui->tableMensagens->setStyleSheet("QHeaderView::section { background-color:lightgray }");
  newItem = new QTableWidgetItem("Mensagem");
  newItem->setTextAlignment(Qt::AlignCenter);
  newItem->setFont(boldFont);
  ui->tableMensagens->setHorizontalHeaderItem(1, newItem);
  newItem = new QTableWidgetItem("St");
  newItem->setTextAlignment(Qt::AlignCenter);
  newItem->setFont(boldFont);
  ui->tableMensagens->setHorizontalHeaderItem(2, newItem);

  // Cria caixas de dialogos de login e de nova conversa
  loginDialog = new LoginDialog(this);
  novaConversa = new NovaConversa(this);
}

WhatsProgMain::~WhatsProgMain()
{
  delete ui;
}

void WhatsProgMain::on_actionNova_conversa_triggered()
{
  novaConversa->show();
}

void WhatsProgMain::on_actionRemover_conversa_triggered()
{

}

void WhatsProgMain::on_actionApagar_mensagens_triggered()
{

}

void WhatsProgMain::on_actionNovo_usuario_triggered()
{
  // Muda o titulo...
  loginDialog->show();
}

void WhatsProgMain::on_actionUsuario_existente_triggered()
{
  // Muda o titulo...
  loginDialog->show();
}

void WhatsProgMain::on_actionDesconectar_triggered()
{

}

void WhatsProgMain::on_actionSair_triggered()
{

}

void WhatsProgMain::on_tableConversas_activated(const QModelIndex &index)
{
  on_tableConversas_clicked(index);
}

void WhatsProgMain::on_tableConversas_clicked(const QModelIndex &index)
{

}

void WhatsProgMain::on_lineEditMensagem_returnPressed()
{

}
