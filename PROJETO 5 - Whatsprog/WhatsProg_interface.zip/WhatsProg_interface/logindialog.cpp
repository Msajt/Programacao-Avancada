#include "logindialog.h"
#include "ui_logindialog.h"
#include "whatsprogmain.h"

LoginDialog::LoginDialog(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::LoginDialog)
{
  ui->setupUi(this);

  ui->lineEditSenhaUsuario->setEchoMode( QLineEdit::Password );
}

LoginDialog::~LoginDialog()
{
  delete ui;
}

void LoginDialog::on_buttonBox_accepted()
{
}
