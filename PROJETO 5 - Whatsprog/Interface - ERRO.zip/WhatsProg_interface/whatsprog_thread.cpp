#include "whatsprog_thread.h"

extern tcp_mysocket sock;

whatsprog_thread::whatsprog_thread(QObject *parent) :
    QObject(parent),
    thr(),
    DC(),
    executa(false)
{
}

// Thread principal
void whatsprog_thread::main_thread()
{
    // O status de retorno das funcoes do socket
      mysocket_status iResult;

      while (sock.connected())
      {
        int32_t cmd;
        iResult = sock.read_int(cmd,1000*TIMEOUT_WHATSPROG);
        if (iResult == mysocket_status::SOCK_OK)
        {
          IterConversa it;
          int32_t id;

          switch(cmd)
          {
          case CMD_NEW_USER:
          case CMD_LOGIN_USER:
          case CMD_LOGIN_OK:
          case CMD_LOGIN_INVALIDO:
          case CMD_MSG_LIDA1:
          case CMD_LOGOUT_USER:
          default:
            // Ignorar: erro do servidor
            break;
          case CMD_NOVA_MSG:
          {
            string remetente;
            string texto;

            // Receber a msg
            iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
            if (iResult == mysocket_status::SOCK_OK) iResult = sock.read_string(remetente, TIMEOUT_WHATSPROG*1000);
            if (iResult == mysocket_status::SOCK_OK) iResult = sock.read_string(texto, TIMEOUT_WHATSPROG*1000);
            if (iResult == mysocket_status::SOCK_OK)
            {
              it = DC.findConversa(remetente);
              if (it == DC.end())
              {
                if (DC.insertConversa(remetente))
                {
                  // A conversa recem-inserida eh a ultima
                  it = DC.last();
                }
              }
              if (it != DC.end())
              {
                // Conversa existe
                Mensagem M;
                // Testa se os parametros da msg estao corretos
                if (M.setId(id) && M.setRemetente(remetente) && M.setDestinatario(DC.getMeuUsuario()) &&
                    M.setTexto(texto) && M.setStatus(MsgStatus::MSG_ENTREGUE))
                {
                  // Insere a mensagem na conversa
                  DC.pushMessage(it,M);
                  // Move a conversa com a nova msg para o inicio da lista (begin)
                  DC.moveConversaToBegin(it);
                  // Modificou o numero de mensagens da conversa
                  // Atualizar a celula correspondente na janela de conversas
                  //** avisaNovaMsg(it);
                }
              }
            }
            else
            {
              // Nao conseguiu ler a msg recebida
              sock.close();
            }
            break;
          } // fim do case CMD_NOVA_MSG
          case CMD_MSG_RECEBIDA:
          case CMD_MSG_ENTREGUE:
          case CMD_MSG_LIDA2:
          {
            int ind_msg;

            // Receber a id
            iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
            if (iResult == mysocket_status::SOCK_OK)
            {
              // Procura se existe uma mensagem com essa id;
              DC.findMensagem(id, it, ind_msg);
              if (it!=DC.end() && ind_msg>=0)
              {
                // Encontrou a msg com essa id
                // Testa o status atual
                bool status_ok(false);
                MsgStatus novoStatus(MsgStatus::MSG_INVALIDA);
                if (cmd==CMD_MSG_RECEBIDA)
                {
                  status_ok = (it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_ENVIADA);
                  novoStatus = MsgStatus::MSG_RECEBIDA;
                }
                if (cmd==CMD_MSG_ENTREGUE)
                {
                  status_ok = (it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_ENVIADA ||
                               it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_RECEBIDA);
                  novoStatus = MsgStatus::MSG_ENTREGUE;
                }
                if (cmd==CMD_MSG_LIDA2)
                {
                  status_ok = (it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_ENVIADA ||
                               it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_RECEBIDA ||
                               it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_ENTREGUE);
                  novoStatus = MsgStatus::MSG_LIDA;
                }
                // Testa o remetente e o status
                if (it->getMensagem(ind_msg).getRemetente()==DC.getMeuUsuario() && status_ok)
                {
                  // A msg encontrada eh de minha autoria e estah com um dos status correto
                  DC.setStatus(it,ind_msg,novoStatus);
                }
                else
                {
                  // A msg com essa id nao estah na situacao esperada
                  // Ignorar: erro do servidor ou do cliente
                }
              }
              else
              {
                // Nao existe msg com essa id
                // Ignorar: erro do servidor ou do cliente
              }
            }
            else
            {
              // Nao conseguiu ler a id
              sock.close();
            }
            break;
          } // fim do case CMD_MSG_<status>
          case CMD_ID_INVALIDA:
          case CMD_USER_INVALIDO:
          case CMD_MSG_INVALIDA:
          {
            int ind_msg;

            // Receber a id
            iResult = sock.read_int(id, TIMEOUT_WHATSPROG*1000);
            if (iResult == mysocket_status::SOCK_OK)
            {
              // Procura se existe uma mensagem com essa id;
              DC.findMensagem(id, it, ind_msg);
              if (it!=DC.end() && ind_msg>=0)
              {
                // Encontrou a msg com essa id
                // Testa o remetente e o status
                if (it->getMensagem(ind_msg).getRemetente()==DC.getMeuUsuario() &&
                    it->getMensagem(ind_msg).getStatus()==MsgStatus::MSG_ENVIADA)
                {
                  // A msg encontrada eh de minha autoria e estah com um dos status apropriado
                  // Remover msg
                  DC.eraseMessage(it,ind_msg);
                  //** QMessageBox::critical(this, "ERRO", "Houve um erro com a mensagem");
                  //** emiteErro("Erro na msg com id="+toString(id)+". Removendo");
                }
                else
                {
                  // A msg com essa id nao estah na situacao esperada
                  // Ignorar: erro do servidor ou do cliente
                }
              }
              else
              {
                // Nao existe msg com essa id
                // Ignorar: erro do servidor ou do cliente
              }
            }
            else
            {
              // Nao conseguiu ler a id
              sock.close();
            }
            break;
          } // Fim do case CMD_<campo>_INVALIDA
          } // Fim do switch
        }
        else // erro na sock.read_int(cmd)
        {
          // A leitura do comando (int) retornou
          // mysocket_status::SOCK_ERROR, mysocket_status::SOCK_DISCONNECTED ou mysocket_status::SOCK_TIMEOUT
          // Se for mysocket_status::SOCK_TIMEOUT, aproveita para salvar o arquivo com os dados
          // Nos outros dois casos, a conexao encerrou, de forma correta ou com erro.
          if (iResult == mysocket_status::SOCK_TIMEOUT)
          {
            if (!DC.salvar())
            {
              //** QMessageBox::critical(this, "ERRO", "Erro no salvamento do arquivo ");
              //** emiteErro("Erro no salvamento do arquivo "+DC.getNomeArq());
            }
          }
          else
          {
            sock.close();
          }
        }
      } // fim do while (sock.connected())

      // Envia o comando de logout
      if (sock.connected())
      {
        sock.write_int(CMD_LOGOUT_USER);
      }

      // Encerra o socket
      sock.close();

      // Salva as informacoes do cliente
      DC.salvar();
}

void main_thread(whatsprog_thread *mct){ mct->main_thread(); }

bool whatsprog_thread::executarThread()
{
    if (!sock.connected())
    {
      // Emitir msg de erro: socket nao conectado
      //emit signErro("Erro na execucao","Socket nao conectado");
      return false;
    }
    if (executa || thr.joinable())
    {
      sock.close();

      // Emitir msg de erro: thread jah estah em execucao
      //emit signErro("Erro na execucao","Thread de leitura jah estah em execucao");
      return false;
    }
    executa = true;
    thr = std::thread(::main_thread, this);
    if (!thr.joinable())
    {
      thr = std::thread();
      executa = false;
      sock.close();

      // Emitir msg de erro: nao foi possivel criar thread
      //emit signErro("Erro na execucao","Nao foi possivel criar thread de leitura");
      return false;
    }
    // Thread estah funcionando
    emit signThreadIniciada();

    return true;
}

void whatsprog_thread::encerrarThread()
{
    // Altera o flag de execucao se jah nao for falso
    executa = false;

    // Fecha o socket se jah nao estiver fechado
    sock.close();

    // Aguarda o encerramento da thread
    if (thr.joinable()) thr.join();

    // Armazena um valor nulo no identificador da thread
    thr = std::thread();
}

