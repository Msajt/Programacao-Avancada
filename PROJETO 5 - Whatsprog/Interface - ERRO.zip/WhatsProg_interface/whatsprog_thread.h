#ifndef WHATSPROG_THREAD_H
#define WHATSPROG_THREAD_H

#include <QObject>
#include <thread>
#include "dados_whatsprog.h"
#include "dados_cliente.h"
#include "mysocket.h"

class whatsprog_thread : public QObject
{
    Q_OBJECT
private:
    std::thread thr;
    DadosCliente DC;
    bool executa;

    void main_thread();
    friend void main_thread(whatsprog_thread *mct);

public:
    explicit whatsprog_thread(QObject *parent = nullptr);
    inline bool executando(){ return executa; }

signals:
    void signThreadIniciada();
    void signThreadEncerrada();

private slots:
    bool executarThread();
    void encerrarThread();
};

#endif // WHATSPROG_THREAD_H
