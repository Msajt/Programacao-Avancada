#include <QApplication>
#include <QMessageBox>

#include "mysocket.h"
#include "whatsprogmain.h"


int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  WhatsProgMain w;

  // Inicializar os sockets
  mysocket_status iResult = mysocket::init();

  if(iResult != mysocket_status::SOCK_OK){
      cerr << "A biblioteca não pode ser iniciada\n";
      exit(1);
  }

  // Exibe a janela principal do aplicativo **
  w.show();

  // Entra no laco sem fim de execucao **
  int result = a.exec();

  /*
  // Espera pelo fim da thread de recepcao
  w.desconectar();
  */

  // Encerra a API de sockets
  mysocket::end();

  return result;
}
